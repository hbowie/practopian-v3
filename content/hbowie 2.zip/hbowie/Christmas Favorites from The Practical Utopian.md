Title:  Christmas Favorites from The Practical Utopian

Tags:   Christmas, humanism

Timestamp: 20210318160930

Status: 9 - Published

Type:   appreciation

Featured: false

Greatest Hits: false

Importance: 100

Date:   20 Dec 2020

Minutes to Read: 1

Image Name: Christmas Favorites

Image Alt: Album covers from four of my favorite Xmas albums

Short ID: cffpu

Teaser: 

The Christmas season is one of my favorite times of year, and I've acquired a huge collection of holiday music over the years, so I thought I would share my thoughts about a few of my favorites with all of you. So here are 20 of my favorite holiday tracks. I've tried to select as wide a variety of songs as possible, mixing different artists and styles. 


Body: 

The Christmas season is one of my favorite times of year, and I've acquired a huge collection of holiday music over the years, so I thought I would share my thoughts about a few of my favorites with all of you. So here are 20 of my favorite holiday tracks. I've tried to select as wide a variety of songs as possible, mixing different artists and styles. 

+ [The Rebel Jesus - Song by Jackson Browne](the-rebel-jesus-song-by-jackson-browne.html)
+ [Father Christmas - Song by The Kinks](father-christmas-song-by-the-kinks.html)
+ [Merry Christmas Baby](merry-christmas-baby.html) - Composed by Charles Brown, performed by Otis Redding
+ [Christmas Time Back Home - Song by The Country Gentlemen](christmas-time-back-home-song-by-the-country-gentlemen.html)
+ [Please Come Home for Christmas](please-come-home-for-christmas.html)
+ [Christmas (Baby Please Come Home)](christmas-baby-please-come-home.html) - Song by Darlene Love and Phil Spector
+ [Holiday in Harlem](holiday-in-harlem.html)
+ [Christmas Night in Harlem](christmas-night-in-harlem.html)
+ [Christmas Bells](christmas-bells.html) by John Gorka
+ [Christmas Must Be Tonight](christmas-must-be-tonight.html) by The Band
+ [Have Yourself a Merry Little Christmas](have-yourself-a-merry-little-christmas.html)
+ [Christmas Song by Dave Mattthews](christmas-song-by-dave-matthews.html)
+ [Auld Lang Syne](auld-lang-syne.html)
+ [The Little Drummer Boy](the-little-drummer-boy.html)
+ [My Favorite Things](my-favorite-things.html)
+ [Star of Wonder](star-of-wonder.html) by The Roches
+ [Christmas Time's A-Coming](christmas-times-a-coming.html)
+ [Boogie Woogie Santa Claus](boogie-woogie-santa-claus.html) by Mabel Scott
+ [The Christmas Song](the-christmas-song.html)
+ [Santa Claus is Coming to Town](santa-claus-is-coming-to-town.html)

And all of these songs but one can be heard on Apple Music in the [Words about Songs - Christmas][pl] playlist. 

Enjoy!

[pl]: https://itunes.apple.com/us/playlist/words-about-songs-christmas/pl.u-DdAN0koTgqpdG
