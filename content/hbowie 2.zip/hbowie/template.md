Title: <title> 

Subtitle:  

Tags: <tags> 

Link: <link> 

Timestamp:  

Status: 0 - Idea; 4 - In Work; 5 - Held; 6 - Completed; 8 - Canceled; 9 - Published;  

Type: pick-from: appreciation, blog 

Featured: <boolean> 

Greatest Hits: <boolean> 

Category: <rank: 1 - Foundational; 2 - Canonical; 3 - Political; 4 - Critical; 5 - Christmas; 6 - Topical; > 

Importance: <seq> 

Date: <date> 

Index: <index> 

Minutes to Read: <minutes-to-read> 

Image Name: <imagename> 

Image Alt:  

Image Caption:  

Image Credit:  

Image Credit Link: <link> 

Medium Link: <link> 

Substack Link: <link> 

Short ID: <shortid> 

Teaser: <longtext> 

Body:  

